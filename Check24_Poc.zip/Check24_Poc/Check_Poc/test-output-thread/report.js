$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([
  {
    "id": "5c3014ac-c0a5-49f0-a502-d5e2b78d6a5a",
    "feature": "Selenium Test Task",
    "scenario": "To verify the Check24 functionality",
    "start": 1647224256527,
    "group": 1,
    "content": "",
    "tags": "",
    "end": 1647224274527,
    "className": "passed"
  }
]);
CucumberHTML.timelineGroups.pushArray([
  {
    "id": 1,
    "content": "Thread[main,5,main]"
  }
]);
});